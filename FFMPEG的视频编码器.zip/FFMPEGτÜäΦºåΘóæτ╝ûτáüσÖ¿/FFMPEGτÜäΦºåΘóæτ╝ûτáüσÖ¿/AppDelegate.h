//
//  AppDelegate.h
//  FFMPEG的视频编码器
//
//  Created by 我的小丫小苹果 on 16/6/17.
//  Copyright © 2016年 Abson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

