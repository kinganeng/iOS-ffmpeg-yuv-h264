//
//  main.m
//  FFMPEG的视频编码器
//
//  Created by 我的小丫小苹果 on 16/6/17.
//  Copyright © 2016年 Abson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
